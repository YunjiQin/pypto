# Kernel and Orchestration Configuration

from pathlib import Path

_ROOT_DIR = Path(__file__).parent

# Runtime configuration for tensormap_and_ringbuffer
# This runtime requires 4 AICPU threads (3 schedulers + 1 orchestrator on thread 3)
RUNTIME_CONFIG = {
	"runtime": "tensormap_and_ringbuffer",
	"aicpu_thread_num": 4,
	"block_dim": 24,
}

ORCHESTRATION = {
	"source": str(_ROOT_DIR / "orchestration" / "main.cpp"),
	"function_name": "aicpu_orchestration_entry"
}

KERNELS = [
	{"func_id": 0, "name": "main_incore_0_aic", "source": str(_ROOT_DIR / "kernels" / "aic" / "main_incore_0_aic.cpp"), "core_type": "aic"},
	{"func_id": 1, "name": "main_incore_0_aiv", "source": str(_ROOT_DIR / "kernels" / "aiv" / "main_incore_0_aiv.cpp"), "core_type": "aiv"},
]
